def fatorial(N):
    
    resultado=1
    count=1

    while count <= N:
        resultado *= count
        count += 1

    return resultado

N = int(input("Quanto alunos tem na sala: "))
M = int(input("Digite quantos alunos tem no Grupo 1: "))
X = N-M

N = fatorial(N)
M = fatorial(M)
X = fatorial(X)

print(f'{N/(M*X)} combinações')