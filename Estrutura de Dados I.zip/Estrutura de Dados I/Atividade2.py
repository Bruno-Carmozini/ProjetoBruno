from function import media

aluno = input("Digite o nome do aluno: ")
nota = int(input(f"Digite a nota do aluno {aluno}:"))

print(f"O status do aluno {aluno} é: {media(nota)}")