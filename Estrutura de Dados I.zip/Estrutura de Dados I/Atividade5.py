from function import area_circulo,perimetro_circulo,area_retangulo,perimetro_retangulo,area_triangulo,perimetro_triangulo

tipo = input("Qual tipo da figura: \n(1) Circunferência \n(2) Triângulo \n(3) Retângulo \nDigite: ")

if tipo == '1':
    tam = float(input("Qual o tamanho do raio da circunferência: "))
    area_circulo(tam)
    perimetro_circulo(tam)

if tipo == '2':
    bt = int(input("Qual o tamanho da altura do triângulo: "))
    a1 = int(input("Qual o tamanho da base do triângulo: "))
    a2 = int(input("Qual o tamanho do 2º do triângulo: "))
    a3 = int(input("Qual o tamanho do 3º do triângulo: "))
    area_triangulo(bt,a1)
    perimetro_triangulo(a1,a2,a3)
   
    

if tipo == '3':
    b = int(input("Qual o tamanho da base do retângulo: "))
    h = int(input("Qual o tamanho da altura do retângulo: "))
    area_retangulo(b,h)
    perimetro_retangulo(b,h)

