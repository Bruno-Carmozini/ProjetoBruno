from function import multiplica,divisao,soma,divisao,limpar,subtrair

while True:

    opcao = input("Opções:\n (1) Somar\n (2) Subtrair\n (3) Multiplicar\n (4) Dividir\n (5) Limpar \n (6) Sair do programa \n Digite:  ")
    
    if opcao == '1':
        variavel = 5
        num = int(input("Digite o operando: "))
        soma(num,variavel)
        
    elif opcao == '2':
        num = int(input("Digite o operando: "))
        subtrair(num,variavel)

    elif opcao == '3':
        num = int(input("Digite o operando: "))
        multiplica(num,variavel)

    elif opcao == '4':
        num = int(input("Digite o operando: "))
        divisao(num,variavel)

    elif opcao == '5':
        limpar(variavel)

    elif opcao == '6':
        break
