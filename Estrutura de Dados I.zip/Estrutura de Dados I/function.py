#Função do Exercício 2

variavel = 5
backup = 5

def media(nota):
    if nota > 6:
        return "Aprovado"
    if nota >=4 and nota <=6:
        return "Verificação Suplementar"
    if nota < 4:
        return "Reprovado"

#Funções do Exercício 3 e 4

def soma(num,EM):
    global variavel
    global backup
    sum = num + variavel
    print("*"*15)
    print(f'O valor da soma é : {sum}')
    print("*"*15)
    variavel = sum
    print(f'O estado da memória agora é: {variavel}')

def subtrair(num,EM):
    global variavel
    global backup
    sub = variavel - num
    print("*"*15)
    print(f'O valor da subtração é : {sub}')
    variavel = sub
    print("*"*15)
    print(f'O estado da memória agora é: {variavel}')


def multiplica(num,EM):
    global variavel
    global backup
    mult = num * variavel
    print("*"*15)
    print(f'O valor da multiplicação é : {mult}')
    variavel = mult
    print("*"*15)
    print(f'O estado da memória agora é: {variavel}')

def divisao(num,EM):
    global variavel
    global backup
    div = variavel/num
    print("*"*15)
    print(f'O valor da divisão é : {div}')
    variavel =  div
    print("*"*15)
    print(f'O estado da memória agora é: {variavel}')

def limpar(EM):
    global variavel
    variavel = backup
    print(f"Estado de memória de volta pro {variavel}")


# Funções do Exercício 5

def area_circulo(tam):
    area = 3.14*(tam**2)
    print(f"A área da cirfunferência é de: {area}")

def perimetro_circulo(tam):
    peri = 2 * 3.14 * tam
    print(f"O perímetro da cirfunferência é de: {round(peri,2)}")

def area_retangulo(b,h):
    area = b*h
    print(f"A área do retângulo é de: {area}")

def perimetro_retangulo(b,h):
    peri = 2*(b+h)
    print(f"O perímetro do retângulo é de: {peri}")

def area_triangulo(a1,bt):
    area = (a1*bt)/2
    print(f"A área do triângulo é de: {area}")

def perimetro_triangulo(a1,a2,a3):
    peri = a1+a2+a3
    print(f"O perímetro do triângulo é de: {peri}")

#Função para o exercício 4

def num2str_expert(valor):
    from num2words import num2words
    texto = num2words(valor, lang="pt-br")
    print(texto)









 