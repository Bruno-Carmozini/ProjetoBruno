function calcular(){

    var v1 = document.getElementById('v1');
    var pri = Number(v1.value);
    
    var v2 = document.getElementById('v2');
    var seg = Number(v2.value);
  
   
    var soma = pri / (seg*seg);
    var imc2 = soma.toFixed(2);


    imc.innerHTML =`IMC: ${imc2}`;





    if (soma < 18.5){
        total.innerHTML = `Abaixo do peso`;
    }

    if(soma > 18.5 && soma < 25){
        total.innerHTML = `Peso ideal`;
    }
    
    if(soma > 25 && soma < 30){
        total.innerHTML = `Sobrepeso`;
    }
    if(soma > 30 && soma < 40){
        total.innerHTML = `Obesidade`;
    }
    if (soma >   40){
        total.innerHTML = `Obesidade mórbida`;
    }
}