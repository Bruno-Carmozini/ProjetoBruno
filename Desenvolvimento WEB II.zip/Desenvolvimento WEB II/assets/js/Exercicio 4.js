function calcular(){

    var v1 = document.getElementById('v1');
    var pri = Number(v1.value);

    
   
    var final = (pri*10)/100
    var final =  pri - final
    total2.innerHTML = `Total a pagar a vista: ${final}`
    
   
}
function calcular1(){

    var v1 = document.getElementById('v1');
    var pri = Number(v1.value);

    
   
    var final = (pri*5)/100
    var final =  pri - final
    total2.innerHTML = `A vista no Débito: ${final}`
    
   
}
function calcular2(){

    var v1 = document.getElementById('v1');
    var pri = Number(v1.value);

    var final = pri/2;
    
    total2.innerHTML = `Até 2x no Crédito: ${pri}`
    total3.innerHTML = `Total Parcela 1: ${final}`
    total4.innerHTML = `Total Parcela 2: ${final}`
    total5.innerHTML = ``
}

function calcular3(){

    var v1 = document.getElementById('v1');
    var pri = Number(v1.value);

    var final = pri/2;
    
    total2.innerHTML = `Até 3x no Crédito: ${pri}`
    total3.innerHTML = `Total Parcela 1: ${final}`
    total4.innerHTML = `Total Parcela 2: ${final}`
    total5.innerHTML = `Total Parcela 3: ${final}`
}