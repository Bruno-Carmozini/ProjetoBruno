function calcular(){

    var v1 = document.getElementById('v1');
    var pri = Number(v1.value);

    var idade = 2022 - pri
    
    total.innerHTML = `Idade: ${idade}`;
    
    if (idade >= 18 && idade <= 70) {

        total2.innerHTML = "Voto Obrigatório";
    }
    else {
        total2.innerHTML = "Voto Opcional";
    }
   
    }

function calcular1(){

    var v1 = document.getElementById('v1');
    var pri = Number(v1.value);
    
    var idade = 2022 - pri
        
    total.innerHTML = `Idade: ${idade}`;
        
    if (idade >= 18 && idade <= 60) {
    
        total2.innerHTML = "Voto Obrigatório";
    }
    else {
        total2.innerHTML = "Voto Opcional";
    }
       
    }