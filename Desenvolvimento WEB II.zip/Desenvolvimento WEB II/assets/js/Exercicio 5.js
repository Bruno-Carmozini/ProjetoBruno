function calcular(){

    var v1 = document.getElementById('v1');
    var pri = Number(v1.value);

    var litro = pri*35
    
    total.innerHTML = `O mínimo de água que você deve beber por dia é:  ${litro}ml`;
    
}