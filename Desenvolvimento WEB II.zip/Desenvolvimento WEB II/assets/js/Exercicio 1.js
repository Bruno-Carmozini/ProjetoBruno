function calcular(){

    var v1 = document.getElementById('v1');
    var pri = Number(v1.value);
    
    var v2 = document.getElementById('v2');
    var seg = Number(v2.value);
    
    var v3 = document.getElementById('v3');
    var tre = Number(v3.value);
    
    var v4 = document.getElementById('v4');
    var four = Number(v4.value);

    var soma = pri + seg + tre;
    var resultado = (soma/four);
    
    total.innerHTML = `Total que cada pessoa irá pagar : ${resultado}`;
    

   
    }